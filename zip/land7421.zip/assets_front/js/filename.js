//alert(1);
var i;
var a = 1000 ;
for (i = 1; i < a; i++) {
CKEDITOR.replace( 'course_content'+i+'' );
CKEDITOR.replace( 'details'+i+'' );
}		