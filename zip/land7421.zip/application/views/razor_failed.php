<!-- Latest compiled and minified CSS -->
<!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous"> -->
<div class="container" style="margin-top:5%;">
	<div class="row">
		<div class="col-md-3"></div>
        <div class="jumbotron" style="box-shadow: 2px 2px 4px #000000;">
            <h2 class="text-center">YOUR PAYMENT FAILED</h2>
          <h3 class="text-center">Please try again </h3>
          
          
            <center><div class="btn-group" style="margin-top:50px;">
                <a href="<?=base_url();?>" class="btn btn-lg btn-warning">Home</a>
            </div></center>
        </div>


	</div>
</div>