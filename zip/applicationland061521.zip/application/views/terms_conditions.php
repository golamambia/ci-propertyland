<div class="banner_area inner_banner text-center" style="background-image:url(https://sharingmakesmehappy.com/assets_front/images/bannerimg.jpg);">
    
</div>
<!-- banner css stop --> 
<!-- main_area css Start -->
<div class="main_area" style="background-image:url(https://sharingmakesmehappy.com/assets_front/images/main_bg.jpg);">
    <div class="container-fluid">
      <div class="main_area_innerbox ">
        <div class="row">
          <div class="col-lg-2"></div>
        <div class="col-lg-8 text-center">
          <aside class="aside_area">
            <div class="aside_innerarea">
              <div class="aside_box">
                <div class="container">
                <div class="row">
                  <div class="col-md-12 about_area">
                    <h2>fhf</h2> 
                  </div>
                </div>
                <div class="row">
                  <div class="col-md-12 about_area">
                    fhfhf
                  </div>
                </div>
                </div>            
              </div>
            </div>
          </aside>
        </div>

        <div class="col-lg-2"></div>
      </div>
    </div>
    </div>
</div>